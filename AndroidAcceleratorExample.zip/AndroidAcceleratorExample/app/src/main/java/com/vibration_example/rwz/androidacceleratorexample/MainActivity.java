package com.vibration_example.rwz.androidacceleratorexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements SensorEventListener{

    private double x, y, z;
    private double leastX=0.0, leastY=0.0, leastZ=0.0;
    private double mostX=0.0, mostY=0.0, mostZ=0.0;
    private TextView xText, yText, zText;
    private TextView leastXText, leastYText, leastZText;
    private TextView mostXText, mostYText, mostZText;
    private Sensor mySensor;
    //private FusedLocationProviderClient mFusedLocationClient;
    private SensorManager sensorManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        setContentView(R.layout.layout);

        // Create our sensor manager.
        sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);

        // Bind the accelerometer sensor to the Sensor mySensor
        mySensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        // Register sensor listener
        sensorManager.registerListener(this, mySensor, SensorManager.SENSOR_DELAY_NORMAL);

        // Assign values to TextViews
        xText = (TextView)findViewById(R.id.xText);
        yText = (TextView)findViewById(R.id.yText);
        zText = (TextView)findViewById(R.id.zText);
        leastXText = (TextView)findViewById(R.id.leastX);
        leastYText = (TextView)findViewById(R.id.leastY);
        leastZText = (TextView)findViewById(R.id.leastZ);
        mostXText = (TextView)findViewById(R.id.mostX);
        mostYText = (TextView)findViewById(R.id.mostY);
        mostZText = (TextView)findViewById(R.id.mostZ);
    }
    @Override
    public void onSensorChanged(SensorEvent event) {
        x = event.values[0];
        y = event.values[1];
        z = event.values[2];
        if(x < leastX) {
            leastX = x;
            leastXText.setText("least X:   " + leastX);
        }
        if(y < leastY) {
            leastY = y;
            leastYText.setText("least Y:   " + leastY);
        }
        if(z < leastZ) {
            leastZText.setText("least Z:   " + leastZ);
        }
        if(x > mostX) {
            mostX = x;
            mostXText.setText("most X:   " + mostX);
        }
        if(y > mostY) {
            mostY = y;
            mostYText.setText("most Y:   " + mostY);
        }
        if(z > mostZ) {
            mostZ = z;
            mostZText.setText("most Z:   " + mostZ);
        }


        xText.setText("X:   "+ x);
        yText.setText("Y:   "+ y);
        zText.setText("Z:   "+ z);




    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {
        // Not used.
    }

}
